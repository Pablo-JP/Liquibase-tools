# PowerShell version of start.sh
# Este script determina el driver, exporta variables de entorno y levanta Docker Compose con el perfil correspondiente.

# Obtener rutas equivalentes a las usadas en bash
$scriptPath = $MyInvocation.MyCommand.Path
$scriptDir  = Split-Path -Parent $scriptPath
$baseDir    = Resolve-Path (Join-Path $scriptDir "..")
$envFile    = Join-Path $scriptDir ".env"
$propsPath  = Join-Path (Join-Path $baseDir "src/main/resources/db") "liquibase.properties"

if (-Not (Test-Path $propsPath)) {
    Write-Host "❌ Archivo de propiedades $propsPath no encontrado." -ForegroundColor Red
    exit 1
}

# Leer driver desde liquibase-schema.properties
$driverLine = Select-String -Path $propsPath -Pattern '^driver='
$driver = ($driverLine.Line -split '=')[1].Trim()

Write-Host "Driver encontrado -> '$driver'"

# Mapear driver a DATABASE y validar
switch ($driver) {
    "oracle.jdbc.OracleDriver" {
        $DATABASE = "ORACLE"
    }
    "com.microsoft.sqlserver.jdbc.SQLServerDriver" {
        $DATABASE = "MSSQL"
    }
    "liquibase.ext.mongodb.database.MongoClientDriver" {
        $DATABASE = "MONGODB"
    }
    default {
        Write-Host "❌ Base de datos no soportada: $driver" -ForegroundColor Red
        Write-Host "Bases de datos soportadas: [oracle.jdbc.OracleDriver, com.microsoft.sqlserver.jdbc.SQLServerDriver, liquibase.ext.mongodb.database.MongoClientDriver]" -ForegroundColor Yellow
        exit 1
    }
}

# Validar archivo .env
if (-Not (Test-Path $envFile)) {
    Write-Host "⚠️  Archivo .env no encontrado en $envFile" -ForegroundColor Yellow
} else {
    # Leer todas las líneas que comienzan con DATABASE_
    $envLines = Get-Content $envFile | Where-Object { $_ -match "^$DATABASE" }

    foreach ($line in $envLines) {
        if ($line -match "^$DATABASE.*?=") {
            $pair = $line -split "=", 2
            $prefix = $pair[0]  # ej: ORACLE_PASSWORD, MSSQL_SA_PASSWORD
            $value  = $pair[1]

            # Quitar prefijo DATABASE_ para obtener la variable final
            $varName = $prefix.Substring($DATABASE.Length + 1)
            [System.Environment]::SetEnvironmentVariable($varName, $value, "Process")
            # Opcional: mostrar variable cargada
            # Write-Host "Set env $varName=$value"
        }
    }
}

Write-Host "🚀 Creando servicios para $DATABASE..."

# Ignorar contenedores huérfanos
$env:COMPOSE_IGNORE_ORPHANS = "1"

# Detectar docker compose disponible
if (Get-Command "docker" -ErrorAction SilentlyContinue) {
    try {
        docker compose version *> $null
        docker compose --profile $DATABASE -f docker/docker-compose.yml up --no-recreate -d
    } catch {
        if (Get-Command "docker-compose" -ErrorAction SilentlyContinue) {
            docker-compose --profile $DATABASE -f docker/docker-compose.yml up --no-recreate -d
        } else {
            Write-Host "❌ No se encontró ni 'docker compose' ni 'docker-compose' en este sistema." -ForegroundColor Red
            exit 1
        }
    }
} elseif (Get-Command "docker-compose" -ErrorAction SilentlyContinue) {
    docker-compose --profile $DATABASE -f docker/docker-compose.yml up --no-recreate -d
} else {
    Write-Host "❌ No se encontró ni 'docker compose' ni 'docker-compose' en este sistema." -ForegroundColor Red
    exit 1
}
