#!/bin/bash

# Directorios base
DIR=$(dirname "$(readlink -f "$0")")
BASE_DIR=$(dirname "$DIR")

# Archivos
ENV_FILE="${DIR}/.env"
PROPERTIES_FILE_NAME="${BASE_DIR}/src/main/resources/db/liquibase.properties"

# Validar que exista el properties
if [ ! -f "$PROPERTIES_FILE_NAME" ]; then
  echo "Archivo de propiedades $PROPERTIES_FILE_NAME no encontrado."
  exit 1
fi

# Extrae el driver y limpia espacios invisibles
DRIVER=$(grep -i "^driver=" "$PROPERTIES_FILE_NAME" | awk -F"=" '{print $2}' | tr -d '\r' | tr -d '\n' | sed 's/^[ \t]*//;s/[ \t]*$//')

echo "Driver encontrado -> '${DRIVER}'"

# Validación solo para Oracle
if [[ "$DRIVER" != "oracle.jdbc.OracleDriver" ]]; then
  echo "Base de datos no soportada: '$DRIVER'"
  echo "Este script solo soporta Oracle"
  exit 1
fi

DATABASE="ORACLE"

# Validar .env
if [ ! -f "$ENV_FILE" ]; then
  echo "Archivo de entorno $ENV_FILE no encontrado."
  exit 1
fi

# Cargar variables de entorno específicas para ORACLE
ENVIROMENTS=$(grep ${DATABASE} ${ENV_FILE} | sed -e "s/${DATABASE}_//")
export ${ENVIROMENTS}

# Ignorar contenedores huérfanos
export COMPOSE_IGNORE_ORPHANS=1

echo "Creando servicios para ${DATABASE}..."

# Primero intentamos con 'docker compose'
if command -v docker &>/dev/null && docker compose version &>/dev/null; then
  docker compose --profile ${DATABASE} -f docker/docker-compose.yml up --no-recreate -d
# Si falla, intentamos con 'docker-compose'
elif command -v docker-compose &>/dev/null; then
  docker-compose --profile ${DATABASE} -f docker/docker-compose.yml up --no-recreate -d
else
  echo "No se encontró ni 'docker compose' ni 'docker-compose' en este sistema."
  exit 1
fi
